![Image of Yaktocat](/assets/logo.PNG)
# VKontakte Discord Bot
:robot: Do you want to add VK integration to your Discord server? This bot help you with that!

## Features
* Russian language support!
* Easy to configure and use!
* Link VK profile to your Discord account!
* Change command prefix!
* Link your VK group and broadcast new posts!

## Bugs
* **Only Russian language**, English support will be added soon.
* Bad written code. **(If you wanna help me just fork this bot and make changes, then make a pull request)**