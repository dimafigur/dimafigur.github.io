import React from 'react';

class Footer extends React.Component {
  render() {
    return (
      <footer>
        <div className="copyright">Copyright &copy; 2019 - The Bastion Bot Project</div>
      </footer>
    );
  }
}

export default Footer;
